<?php

class themeTag
{
	public function index()
	{
		Cache::loadPage('',30);
				
		$inputData=array();

		$postid=0;

		$curPage=0;
		// Model::loadWithPath('home',System::getThemePath().'model/');

		if(!$match=Uri::match('tag\/([a-zA-Z0-9_\-\s\_]+)'))
		{
			Redirect::to('404page');
		}

		$friendly_url=trim(addslashes($match[1]));

		if($match=Uri::match('page\/(\d+)'))
		{
			$curPage=(int)$match[1];
		}


		$loadData=Post::get(array(
			'limitShow'=>10,
			'limitPage'=>$curPage,
			'cacheTime'=>30,
			'where'=>"where postid IN (select postid from post_tags where title='$friendly_url')",
			'orderby'=>"order by postid desc"
			));


		$inputData['listPost']=$loadData;

		$inputData['keywords']=$friendly_url;

		$inputData['listPage']=Misc::genSmallPage('tag/'.$friendly_url,$curPage);

		System::setTitle('Tag "'.$friendly_url.'" results:');

		self::makeContent('tag',$inputData);

		Cache::savePage();	
	}

	public function makeContent($viewName,$inputData=array())
	{
		$themePath=System::getThemePath().'view/';

		$inputData['themePath']=$themePath;

		View::makeWithPath('head',array(),$themePath);

		View::makeWithPath($viewName,$inputData,$themePath);

		View::makeWithPath('right',array(),$themePath);

		View::makeWithPath('footer',array(),$themePath);

	}


}

?>