<?php

class themePage
{
	public function index()
	{
		// Cache::loadPage('',30);

		$inputData=array();

		$postid=0;

		Model::loadWithPath('page',System::getThemePath().'model/');

		if(!$match=Uri::match('page\/(.*?)\.html$'))
		{
			Redirect::to('404page');
		}

		$friendly_url=addslashes($match[1]);

		$loadData=Pages::get(array(
			'cacheTime'=>30,
			'isHook'=>'yes',
			'where'=>"where friendly_url='$friendly_url'"
			));

		if(!isset($loadData[0]['title']))
		{
			Redirect::to('404page');
		}


		$inputData=$loadData[0];

		$inputData['page_title']=$inputData['title'];

		$postid=$loadData[0]['pageid'];

		if(Uri::isNull())
		{
			System::setTitle(ucfirst($loadData[0]['title']));
		}

		$themePath=System::getThemePath().'view/';

		$inputData['themePath']=$themePath;

		$keywords=isset($loadData[0]['keywords'][4])?$loadData[0]['keywords']:System::getKeywords();

		System::setKeywords($keywords);


		View::makeWithPath('head',array(),$themePath);

		if($loadData[0]['page_type']=='fullwidth')
		{
			View::makeWithPath('pageFullWidth',$inputData,$themePath);
		}
		else
		{
			View::makeWithPath('page',$inputData,$themePath);
			View::makeWithPath('right',array(),$themePath);

		}

			View::makeWithPath('footer',array(),$themePath);

		// Cache::savePage();
	}




}

?>