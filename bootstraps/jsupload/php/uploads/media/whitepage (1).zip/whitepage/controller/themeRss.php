<?php

class themeRss
{
	public function index()
	{
		$themePath=System::getThemePath().'view/';

		$pageData=array();
Response::rss();
		$pageData['listPost']=Post::get(array(
			'isHook'=>'yes',
			'limitShow'=>20,
			'cacheTime'=>30,
			'where'=>"where status='1'",
			'orderby'=>" order by postid desc"
			));

		if($match=Uri::match('\/atom'))
		{

			View::makeWithPath('rssAtom',$pageData,$themePath);
		}
		else
		{
			
			View::makeWithPath('rss',$pageData,$themePath);
		}
		
		
	}
}


?>