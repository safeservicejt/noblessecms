<?php

class themeSearch
{
	public function index()
	{
		Cache::loadPage('',30);

		$inputData=array();

		$postid=0;

		$curPage=0;
		// Model::loadWithPath('home',System::getThemePath().'model/');


		if($match=Uri::match('page\/(\d+)'))
		{
			$curPage=(int)$match[1];
		}

		$txtKeywords=addslashes(Request::get('txtKeywords',''));

		if($match=Uri::match('\/keyword\/(.*?)\/page'))
		{
			$txtKeywords=base64_decode($match[1]);
		}

		$loadData=Post::get(array(
			'limitShow'=>10,
			'limitPage'=>$curPage,
			'cacheTime'=>30,
			'isHook'=>'yes',
			'where'=>"where title LIKE '%$txtKeywords%'",
			'orderby'=>"order by postid desc"
			));


		$inputData['listPost']=$loadData;

		$inputData['keywords']=$txtKeywords;

		$inputData['listPage']=Misc::genSmallPage('search/keyword/'.base64_encode($txtKeywords),$curPage);

		System::setTitle('Search result with keyword "'.$txtKeywords.'" results:');

		self::makeContent('search',$inputData);

		Cache::savePage();

	}

	public function makeContent($viewName,$inputData=array())
	{
		$themePath=System::getThemePath().'view/';

		$inputData['themePath']=$themePath;

		View::makeWithPath('head',array(),$themePath);

		View::makeWithPath($viewName,$inputData,$themePath);

		View::makeWithPath('right',array(),$themePath);

		View::makeWithPath('footer',array(),$themePath);

	}


}

?>