<?php 

$themePath=THEMES_PATH.'whitepage/cp/';

include($themePath.'controller/controlSetting.php');

?>