
<div class="row">
<!-- left -->
  <div class="col-lg-3">
    <div class="panel panel-default">
      <div class="panel-heading">
        <h3 class="panel-title">Menu</h3>
      </div>
      <div class="panel-body bodyMenu">
        <ul class="themeMenu">
          <li><a href="<?php echo System::getUrl();?>admincp/theme/setting/whitepage">General</a></li>

        </ul>
      </div>
    </div>    
  </div>
<!-- left -->