<?php

function settingProcess()
{
	$send=Request::get('send');

	saveSetting($send);

	$imgName=$_FILES['imgLogo']['name'];

	if(isset($imgName[2]) && !preg_match('/^.*?\.(png|gif|jpe?g)$/i', $imgName))
	{
		throw new Exception("Only allow image file");
	}
	else
	{
		if(isset($imgName[2]))
		{
			$imgPath='uploads/images/'.Database::getPrefix().$imgName;

			if(move_uploaded_file($_FILES['imgLogo']['tmp_name'], ROOT_PATH.$imgPath))
			{
				$loadSize=filesize(ROOT_PATH.$imgPath);

				if((int)$loadSize > 1000000)
				{
					unlink(ROOT_PATH.$imgPath);

					throw new Exception('We not allow file large than 1MB.');
				}

				$send['site_logo']=$imgPath;
			}

			saveSetting($send);
			
		}
	}



}


function saveSetting($inputData=array())
{
	$total=count($inputData);

	if((int)$total > 0)
	{	
		$loadData=array();

		if($loadData=Cache::loadKey('dbcache/'.Database::getPrefix().'whitepage',-1))
		{
			$loadData=unserialize($loadData);
		}

		$listKeys=array_keys($inputData);

		for ($i=0; $i < $total; $i++) { 
			$theKey=$listKeys[$i];

			$loadData[$theKey]=$inputData[$theKey];
		}

		$loadData=serialize($loadData);

		Cache::saveKey('dbcache/'.Database::getPrefix().'whitepage',$loadData);
	}

}

function loadSetting()
{
	$default=array(
		'facebook_app_id'=>'',
		'theme_background_color'=>'#efefef',
		'theme_color'=>'blue',
		'site_right_content'=>'',
		'site_logo'=>System::getUrl().'contents/themes/whitepage/images/logo.png',
		'theme_link_color'=>'#a5a5a5'
		);

	if(!$loadData=Cache::loadKey('dbcache/'.Database::getPrefix().'whitepage',-1))
	{
		return $default;
	}

	$loadData=unserialize($loadData);

	$loadData['facebook_app_id']=isset($loadData['facebook_app_id'])?$loadData['facebook_app_id']:'675779382554952';

	$loadData['theme_background_color']=isset($loadData['theme_background_color'])?$loadData['theme_background_color']:'#efefef';
	$loadData['theme_color']=isset($loadData['theme_color'])?$loadData['theme_color']:'red';

	$loadData['site_right_content']=isset($loadData['site_right_content'])?$loadData['site_right_content']:'';

	$loadData['site_logo']=isset($loadData['site_logo'])?$loadData['site_logo']:System::getUrl().'contents/themes/whitepage/images/logo.png';


	$loadData['theme_link_color']=isset($loadData['theme_link_color'])?$loadData['theme_link_color']:'#a5a5a5';

	return $loadData;
}

?>