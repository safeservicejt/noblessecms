<style type="text/css">
.bodyMenu
{
  padding: 0px;

  /*padding-left: 10px;*/
}
.themeMenu
{
  list-style: none;
  padding: 0px;
  margin:0px;
}  
.themeMenu li
{
  display: block;
  padding: 0px;
  margin:0px;  
  /*padding: 7px 0px 7px 0px;*/
}
.themeMenu li a,
.themeMenu li a:link,
.themeMenu li a:visited
{
  padding: 7px 5px 7px 15px;
  display: block;
  border-bottom: 1px solid #e5e5e5;
}
.themeMenu li:hover
{
  background-color: #2780e3;
}
.themeMenu li:hover a
{
  text-decoration: none;
  color: #ffffff;
}
</style>
   <link href="<?php echo ROOT_URL;?>bootstrap/colorpicker/css/bootstrap-colorpicker.min.css" rel="stylesheet">
    <script src="<?php echo ROOT_URL;?>bootstrap/colorpicker/js/bootstrap-colorpicker.min.js"></script>

