<?php

$pageData=array();

$pageName=System::getCurrentPage();

$pageName=($pageName=='')?'home':$pageName;

if($matches=Uri::match('^(\w+)\/?'))
{
	$pageName=$matches[1];
}

if($matches=Uri::match('^page\/(\d+)'))
{
	$pageName='home';
}

// Theme::view('head');
$codeHead=Plugins::load('site_header');

$codeHead=is_array($codeHead)?'':$codeHead;

$codeFooter=Plugins::load('site_footer');

$codeFooter=is_array($codeFooter)?'':$codeFooter;

// print_r($codeHead);die();

System::defineGlobalVar('site_header',$codeHead);

System::defineGlobalVar('site_footer',$codeFooter);

if($loadData=Cache::loadKey('dbcache/'.Database::getPrefix().'whitepage',-1))
{
	$loadData=unserialize($loadData);

	System::defineGlobalVar('themeSetting',$loadData);

}

$links=Links::get(array(
	'cache'=>'yes',
	'cacheTime'=>30,
	'orderby'=>'order by sort_order asc'
	));

$listPost=Post::get(array(
	'limitShow'=>5,
	'cache'=>'yes',
	'cacheTime'=>30,
	'orderby'=>'order by postid desc'
	));

System::defineGlobalVar('siteTitle',System::getTitle());

System::defineVar('linkList',$links,'head');

System::defineGlobalVar('postList',$listPost);

System::defineGlobalVar('title',System::getTitle());

Controller::loadWithPath('theme'.ucfirst($pageName),'index',System::getThemePath().'controller/');

// Theme::view('footer');

?>