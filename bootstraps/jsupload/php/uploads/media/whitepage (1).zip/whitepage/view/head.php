<!DOCTYPE html>
<html lang="en">
  <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="keywords" content="<?php echo System::getKeywords();?>">
        <meta name="description" content="<?php echo System::getDescriptions();?>">
        <link rel="shortcut icon" href="<?php echo System::getUrl();?>bootstrap/favicon.ico">
        <meta name="author" content="Safeservicejt">
        <meta name="url" id="root_url" content="<?php echo System::getUrl();?>">

        <title><?php echo System::getTitle();?></title>
  <link rel="alternate" type="application/rss+xml" title="RSS 2.0" href="<?php echo System::getUrl();?>feed/" />
  <link rel="alternate" type="application/atom+xml" title="Atom 1.0" href="<?php echo System::getUrl();?>feed/atom/" />


    <!-- Bootstrap theme -->
     <link href="<?php echo System::getThemeUrl();?>css/bootstrap.min.css" rel="stylesheet">
    
       <link href="<?php echo System::getThemeUrl();?>css/custom.css" rel="stylesheet">
       <?php if(isset($themeSetting['theme_color'])){ ?>
       <link href="<?php echo System::getThemeUrl();?>css/color_<?php if(isset($themeSetting['theme_color']))echo $themeSetting['theme_color']; ?>.css" rel="stylesheet">
       <?php } ?>

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
      <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
       
      <script src="<?php echo System::getThemeUrl();?>js/jquery-2.1.1.min.js"></script>
      <script src="<?php echo System::getThemeUrl();?>js/jquery-2.1.1.min.map"></script>
              <script src="<?php echo System::getUrl();?>bootstrap/js/system.js"></script>
 
        <!-- bxSlider Javascript file -->
        <script src="<?php echo System::getUrl();?>bootstrap/bxslider/jquery.bxslider.min.js"></script>
        <!-- bxSlider CSS file -->
        <link href="<?php echo System::getUrl();?>bootstrap/bxslider/jquery.bxslider.css" rel="stylesheet" />
      
      <script src="<?php echo System::getThemeUrl();?>js/custom.js"></script>
      
      <?php echo System::getVar('site_header');?>


            
  </head>

  <body>
<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.4&appId=<?php if(isset($themeSetting['facebook_app_id']))echo $themeSetting['facebook_app_id'];?>";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>

  <!-- body -->
  <div class="container">
    <div class="row">
      <div class="col-lg-12 col-wrapper">
        <div class="wrapper">
          <!-- banner -->
          <div class="row row-banner">
            <div class="col-lg-12 col-banner">
              <?php if(!isset($themeSetting['site_logo'])){ ?>
                <a href="<?php echo System::getUrl();?>" title="<?php echo System::getTitle();?>"><img src="<?php echo System::getThemeUrl();?>images/logo.png"></a>
                <?php }else{ ?>
                <a href="<?php echo System::getUrl();?>" title="<?php echo System::getTitle();?>"><img src="<?php echo $themeSetting['site_logo'];?>"></a>
                <?php } ?>
            </div>
          </div>
          <!-- banner -->


          <!-- menu -->
          <div class="row row-menu">
            <div class="col-lg-12 col-menu">
              <ul>
                <?php

                $total=count($linkList);

                $li='';

                if(isset($linkList[0]['id']))
                {
                  for ($i=0; $i < $total; $i++) { 
                    $li.='<li><a title="'.$linkList[$i]['title'].'" href="'.$linkList[$i]['urlFormat'].'">'.$linkList[$i]['title'].'</a></li>';
                  }
                }

                echo $li;
                ?>
              </ul>
            </div>
          </div>
          <!-- menu -->

          <!-- content -->
          <div class="row row-content">
            <div class="col-lg-12 col-content">
              <!-- row -->
              <div class="row">          