                <!-- left -->
                <div class="col-lg-8 col-left">
                <?php
                if(isset($listPost[0]['postid']))
                {
                  $total=count($listPost);

                  $li='';

                  for ($i=0; $i < $total; $i++) { 
                    $li.='
                    <!-- item -->
                    <div class="row">
                      <div class="col-lg-12 col-item">
                        <a href="'.$listPost[$i]['url'].'"><h3>'.$listPost[$i]['title'].'</h3></a>
                        <div class="info">
                          <span><span class="glyphicon glyphicon-calendar"></span> '.date('d M, Y',strtotime($listPost[$i]['date_added'])).'</span>
                        </div>
                        <div class="body">
                        '.$listPost[$i]['content'].'
                        </div>
                      </div>
                    </div>
                    <!-- item -->

                    ';
                  }

                  echo $li;
                }
                else
                {
                  echo '<h3>There not post found.</h3>';
                }
                ?>      
                
                <!-- page -->
                <div class="row">
                  <div class="col-lg-12 text-right">
                   <?php echo $listPage;?>                               
                  </div>
                </div>
                <!-- page -->                

                </div>
                <!-- left -->