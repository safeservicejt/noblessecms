        <!-- left -->
        <div class="col-lg-8">
          <div class="item-title">
            <a href="sdd"><h3>No content there</h3></a>
          </div>

          <div class="item-content">
            Go to <strong>Admincp</strong> and <strong>create new page</strong>. Then <strong>set that page is default page</strong> for change this page content!


          </div>

        </div>
        <!-- left -->