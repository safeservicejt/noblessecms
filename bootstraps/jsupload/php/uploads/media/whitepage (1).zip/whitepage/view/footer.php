
              </div>
              <!-- row -->
            </div>
          </div>
          <!-- content -->
        </div>
      </div>
    </div>
  </div>
  <!-- body -->


  <!-- footer -->
  <div class="container">
    <div class="row">
      <div class="col-lg-12 col-footer">
        Powered by <a href="http://noblessecms.com/" target="_blank">Noblesse CMS</a>
      </div>
    </div>
  </div>  
  <!-- footer -->
    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->

    <script src="<?php echo System::getThemeUrl();?>js/bootstrap.min.js"></script>
      <?php echo System::getVar('site_footer');?>

  </body>
</html>