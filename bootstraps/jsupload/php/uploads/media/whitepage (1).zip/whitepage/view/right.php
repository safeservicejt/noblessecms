                <!-- right -->
                <div class="col-lg-4">
                  <!-- item -->
                  <div class="row">
                    <div class="col-lg-12 col-widget">
                      <div class="title">
                        <span>Lastest Post</span>
                      </div>
                      <div class="content">
                        <ul class="list-right">
                          <?php 
                          if(isset($postList))
                          {
                            $li='';

                            $total=count($postList);

                            if(isset($postList[0]['postid']))
                            for ($i=0; $i < $total; $i++) { 
                              $li.='<li><a href="'.$postList[$i]['url'].'" title="'.$postList[$i]['title'].'">'.ucwords($postList[$i]['title']).'</a></li>';
                            }

                            echo $li; 
                          }

                          ?>
                        </ul>
                      </div>
                    </div>
                  </div>
                  <!-- item -->                
                  
                  <?php if(isset($themeSetting['site_right_content']))echo $themeSetting['site_right_content'];?>

                </div>
                <!-- right -->