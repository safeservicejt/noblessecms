        <!-- left -->
        <div class="col-lg-8">
          <div class="item-title">
            <a href="sdd"><h3>Contact Us</h3></a>
          </div>

          <div class="item-content">
			<form action="" method="post" enctype="multipart/form-data">
				<?php echo $alert;?>
				<p>
				<label><strong>Fullname</h3>
				</strong></label>
				<input type="text" class="form-control" placeholder="Fullname" name="send[fullname]" required />
				</p>
				<p>
				<label><strong>Email</h3>
				</strong></label>
				<input type="email" class="form-control" placeholder="Email" name="send[email]" required />
				</p>
				<p>
				<label><strong>Content</h3>
				</strong></label>
				<textarea rows="10" class="form-control" placeholder="Content" name="send[content]"></textarea>
				</p>
				  <br>
				  <?php echo $captchaHTML;?>			
				  <br>			
				<button type="submit" class="btn btn-primary" name="btnSend">Send</button>

				<a href="<?php echo ROOT_URL;?>" class="btn btn-default pull-right">Back</a>
			</form>  

          </div>

        </div>
        <!-- left -->

