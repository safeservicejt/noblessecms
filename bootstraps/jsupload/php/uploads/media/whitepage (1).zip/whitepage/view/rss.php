<?php echo '<?xml version="1.0" encoding="UTF-8"?>';?><rss version="2.0"
    xmlns:content="http://purl.org/rss/1.0/modules/content/"
    xmlns:wfw="http://wellformedweb.org/CommentAPI/"
    xmlns:dc="http://purl.org/dc/elements/1.1/"
    xmlns:atom="http://www.w3.org/2005/Atom"
    xmlns:sy="http://purl.org/rss/1.0/modules/syndication/"
    xmlns:slash="http://purl.org/rss/1.0/modules/slash/">
    <channel>
        <title><?php echo System::getTitle();?></title>
        <atom:link href="<?php echo System::getUrl().'rss';?>" rel="self" type="application/rss+xml" />
        <description><?php echo System::getDescriptions();?></description>
        <ttl>10</ttl>
        <copyright><?php echo System::getUrl();?></copyright>
        <pubDate><?php echo date("d/m/Y H:m:s");?></pubDate>
   
        <link><?php echo System::getUrl();?></link>
        <description></description>
        <lastBuildDate><?php echo date("d/m/Y H:m:s");?></lastBuildDate>
        <language>en-US</language>
        <sy:updatePeriod>daily</sy:updatePeriod>
        <sy:updateFrequency>1</sy:updateFrequency>
        <generator>http://noblessecms.com</generator>
        <?php
        $total=count($listPost);

        $li='';

        if(isset($listPost[0]['title']))
        for($i=0;$i<$total;$i++)
        {
            $li.='<item>
                <title>'.$listPost[$i]['title'].'</title>
                <link>'.$listPost[$i]['url'].'</link>
                <image>'.System::getUrl().$listPost[$i]['image'].'</image>
                <guid isPermaLink="false">'.$listPost[$i]['url'].'</guid>
                <description>'.substr(htmlentities($listPost[$i]['content']), 0,150).'</description>
                <pubDate>'.$listPost[$i]['date_added'].'</pubDate>
                 </item>';
        }

        echo $li;
        ?>




    </channel>
</rss>