        <!-- left -->
        <div class="col-lg-8">
          <div class="item-title">
            <a href="sdd"><h3><?php echo $post_title;?></h3></a>
          </div>

          <div class="item-content">
            <?php echo $content;?>
          </div>

        </div>
        <!-- left -->

