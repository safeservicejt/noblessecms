<?php echo '<?xml version="1.0" encoding="UTF-8"?>';?><feed
  xmlns="http://www.w3.org/2005/Atom"
  xmlns:thr="http://purl.org/syndication/thread/1.0"
  xml:lang="en-US"
  xml:base="http://www.catheadphones.com/wp-atom.php"
   >
 
        <title><?php echo System::getTitle();?></title>
        <link rel="alternate" type="text/html" href="<?php echo System::getUrl();?>" />
        <link rel="self" type="application/atom+xml" href="<?php echo System::getUrl().'rss/atom/';?>" />
        <generator uri="http://noblessecms.com/" version="4.3">Noblesse CMS</generator>   
        <id><?php echo System::getUrl().'rss/atom/';?></id>
        <subtitle type="text"></subtitle>
        <updated><?php echo date("d/m/Y H:m:s");?></updated>

       
             
        <?php
        $total=count($listPost);

        $li='';

        if(isset($listPost[0]['title']))
        for($i=0;$i<$total;$i++)
        {
            $li.='
<entry>
        <author>
            <name>admin</name>
                    </author>
        <title type="html"><![CDATA['.$listPost[$i]['title'].']]></title>
        <link rel="alternate" type="text/html" href="'.$listPost[$i]['url'].'" />
        <id>'.$listPost[$i]['url'].'</id>
        <updated>'.$listPost[$i]['date_added'].'</updated>
        <published>'.$listPost[$i]['date_added'].'</published>
        <summary type="html"><![CDATA['.$listPost[$i]['title'].']]></summary>
        <content type="html" xml:base="'.$listPost[$i]['url'].'"><![CDATA['.$listPost[$i]['title'].']]></content>
        <thr:total>0</thr:total>
    </entry>
                 ';
        }

        echo $li;
        ?>
</feed>