Noblesse CMS is a modern and lightweight Content Management System. Faster more than 300% -> 500% others system!

Support multi websites & big data :). All question you can sent to freshcodeteam@gmail.com

Featureds:

- Easy manage your system with friendly administrator cpanel

- Easy build plugins/themes, administrator setting cpanel

- Easy build custom shortcode

- Support build multi layouts for themes (support MVC for each layout)

- Support show/hide any container/elements in system/admincp (full customization)

- Support add/remove/update permission for usergroup. Also, you can add your custom permission to usergroups

Homepage: http://noblessecms.com/

Facebook page: https://www.facebook.com/noblessecmspage

Facebook group: https://www.facebook.com/groups/noblessecmsgroup/

How to install:

- Download zip file then upload into your host, extract zip file and go to http://yoursite.com/install/

- Follow steps to complete install NoblesseCMS and remove install folder after completed install

- Thanks for use!

With Noblesse CMS we can provide Lumi Cache Solution: Not connect to database to get/show data, final read/show data in cache. Your website will get max speed with Lumi Cache Solution !
