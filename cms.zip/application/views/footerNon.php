

    <!-- Bootstrap Core JavaScript -->
    <script src="<?php echo System::getUrl();?>bootstraps/sbnoblesse/js/bootstrap.min.js"></script>
    

</body>

</html>
