<div class="panel panel-default">
  <div class="panel-heading">
    <h3 class="panel-title">View contact from <?php echo $fullname;?></h3>
  </div>
  <div class="panel-body">
    <div class="row">
    	<div class="col-lg-12">
        <p>
            <strong><?php echo $fullname;?></strong>
            <br>
            <small>Date: <?php echo $date_added;?></small>
            <br>
            <small>Email: <?php echo $email;?></small>

        </p>
        <hr>
    	<?php echo $content;?>
    	</div>
    	
    </div>
  </div>
</div>

