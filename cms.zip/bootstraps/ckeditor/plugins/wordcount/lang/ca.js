﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang('wordcount', 'ca', {
    WordCount: 'Paraules:',
    CharCount: 'Caràcters:',
    CharCountWithHTML: 'Caràcters (including HTML):',
    Paragraphs: 'Paragraphs:',
    pasteWarning: 'Content can not be pasted because it is above the allowed limit',
    Selected: 'Selected: ',
    title: 'Estadístiques'
});
